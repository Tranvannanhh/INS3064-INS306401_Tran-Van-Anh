<?php
require_once '../classes/Database.php';
$pdo = Database::connect();

$sql = "
SELECT e.id,
       s.name AS student_name,
       s.email,
       c.title AS course_title,
       e.enrolled_at
FROM enrollments e
JOIN students s ON e.student_id = s.id
JOIN courses c ON e.course_id = c.id
ORDER BY e.enrolled_at DESC
";

$data = $pdo->query($sql)->fetchAll();
?>

<h2>Enrollment List</h2>
<a href="create.php">Enroll New</a>

<table border="1">
<tr>
  <th>Student</th>
  <th>Email</th>
  <th>Course</th>
  <th>Date</th>
  <th>Action</th>
</tr>

<?php foreach ($data as $row): ?>
<tr>
  <td><?= htmlspecialchars($row['student_name']) ?></td>
  <td><?= htmlspecialchars($row['email']) ?></td>
  <td><?= htmlspecialchars($row['course_title']) ?></td>
  <td><?= $row['enrolled_at'] ?></td>
  <td>
    <a href="delete.php?id=<?= $row['id'] ?>">Delete</a>
  </td>
</tr>
<?php endforeach; ?>
</table>