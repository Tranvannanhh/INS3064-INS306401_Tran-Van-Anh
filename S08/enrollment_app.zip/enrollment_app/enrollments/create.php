<?php
require_once '../classes/Database.php';
$pdo = Database::connect();

// lấy danh sách student
$students = $pdo->query("SELECT * FROM students")->fetchAll();

// lấy danh sách course
$courses = $pdo->query("SELECT * FROM courses")->fetchAll();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $student_id = $_POST['student_id'];
    $course_id = $_POST['course_id'];

    try {
        $stmt = $pdo->prepare(
            "INSERT INTO enrollments(student_id, course_id) VALUES (?, ?)"
        );
        $stmt->execute([$student_id, $course_id]);

        header("Location: index.php");

    } catch (PDOException $e) {
        echo "Student already enrolled in this course!";
    }
}
?>

<h2>Enroll Student</h2>

<form method="POST">

  Student:
  <select name="student_id">
    <?php foreach ($students as $s): ?>
      <option value="<?= $s['id'] ?>">
        <?= htmlspecialchars($s['name']) ?>
      </option>
    <?php endforeach; ?>
  </select>

  Course:
  <select name="course_id">
    <?php foreach ($courses as $c): ?>
      <option value="<?= $c['id'] ?>">
        <?= htmlspecialchars($c['title']) ?>
      </option>
    <?php endforeach; ?>
  </select>

  <button>Enroll</button>
</form>