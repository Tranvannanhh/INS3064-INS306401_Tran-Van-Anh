<?php
require_once '../classes/Database.php';
$pdo = Database::connect();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = $_POST['title'];
    $description = $_POST['description'];

    if (empty($title)) {
        echo "Title is required!";
    } else {
        $stmt = $pdo->prepare(
            "INSERT INTO courses(title, description) VALUES (?, ?)"
        );
        $stmt->execute([$title, $description]);

        header("Location: index.php");
    }
}
?>

<h2>Add Course</h2>

<form method="POST">
  Title: <input name="title"><br>
  Description: <textarea name="description"></textarea><br>
  <button>Add</button>
</form>