<?php
require_once '../classes/Database.php';
$pdo = Database::connect();

$data = $pdo->query("SELECT * FROM courses")->fetchAll();
?>

<h2>Courses</h2>
<a href="create.php">Add Course</a>

<table border="1">
<tr>
  <th>Title</th>
  <th>Description</th>
  <th>Action</th>
</tr>

<?php foreach ($data as $c): ?>
<tr>
  <td><?= htmlspecialchars($c['title']) ?></td>
  <td><?= htmlspecialchars($c['description']) ?></td>
  <td>
    <a href="delete.php?id=<?= $c['id'] ?>">Delete</a>
  </td>
</tr>
<?php endforeach; ?>
</table>