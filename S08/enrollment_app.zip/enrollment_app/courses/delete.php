<?php
require_once '../classes/Database.php';
$pdo = Database::connect();

$id = $_GET['id'];

$stmt = $pdo->prepare("DELETE FROM courses WHERE id=?");
$stmt->execute([$id]);

header("Location: index.php");