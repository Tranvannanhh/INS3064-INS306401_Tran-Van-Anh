<?php
require_once '../classes/Database.php';
$pdo = Database::connect();

$id = $_GET['id'];

// lấy dữ liệu cũ
$stmt = $pdo->prepare("SELECT * FROM courses WHERE id=?");
$stmt->execute([$id]);
$course = $stmt->fetch();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = $_POST['title'];
    $desc = $_POST['description'];

    $stmt = $pdo->prepare(
        "UPDATE courses SET title=?, description=? WHERE id=?"
    );
    $stmt->execute([$title, $desc, $id]);

    header("Location: index.php");
}
?>

<form method="POST">
  Title: <input name="title" value="<?= $course['title'] ?>"><br>
  Description: <textarea name="description"><?= $course['description'] ?></textarea><br>
  <button>Update</button>
</form>