<?php
require_once '../classes/Database.php';
$pdo = Database::connect();

$data = $pdo->query("SELECT * FROM students")->fetchAll();
?>

<h2>Students</h2>
<a href="create.php">Add</a>

<table border="1">
<tr>
  <th>Name</th>
  <th>Email</th>
  <th>Action</th>
</tr>

<?php foreach ($data as $s): ?>
<tr>
  <td><?= htmlspecialchars($s['name']) ?></td>
  <td><?= htmlspecialchars($s['email']) ?></td>
  <td>
    <a href="delete.php?id=<?= $s['id'] ?>">Delete</a>
  </td>
</tr>
<?php endforeach; ?>
</table>