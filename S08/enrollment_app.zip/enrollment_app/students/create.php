<?php
require_once '../classes/Database.php';
$pdo = Database::connect();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'];
    $email = $_POST['email'];

    // check email trùng
    $check = $pdo->prepare("SELECT id FROM students WHERE email=?");
    $check->execute([$email]);

    if ($check->rowCount() > 0) {
        echo "Email exists!";
    } else {
        $stmt = $pdo->prepare("INSERT INTO students(name, email) VALUES (?, ?)");
        $stmt->execute([$name, $email]);
        header("Location: index.php");
    }
}
?>

<form method="POST">
  Name: <input name="name"><br>
  Email: <input name="email"><br>
  <button>Add</button>
</form>