<?php
require_once '../classes/Database.php';
$pdo = Database::connect();

$id = $_GET['id'];
$pdo->prepare("DELETE FROM students WHERE id=?")->execute([$id]);

header("Location: index.php");